// Function to initialize image comparisons
function initComparisons() {
    var overlays = document.getElementsByClassName("img-comp-overlay");

    // Iterate over each overlay element
    for (var i = 0; i < overlays.length; i++) {
        // Call compareImages function for each overlay
        compareImages(overlays[i]);
    }

    // Function to compare two images
    function compareImages(overlay) {
        var slider, clicked = 0, w, h;

        // Get width and height of the overlay image
        w = overlay.offsetWidth;
        h = overlay.offsetHeight;

        // Set width of the overlay image to 50%
        overlay.style.width = (w / 2) + "px";

        // Create slider element
        slider = document.createElement("DIV");
        slider.setAttribute("class", "img-comp-slider");

        // Insert slider before the overlay image
        overlay.parentElement.insertBefore(slider, overlay);

        // Position the slider in the middle
        slider.style.top = (h / 2) - (slider.offsetHeight / 2) + "px";
        slider.style.left = (w / 2) - (slider.offsetWidth / 2) + "px";

        // Event listeners for mouse and touch events
        slider.addEventListener("mousedown", slideReady);
        window.addEventListener("mouseup", slideFinish);
        slider.addEventListener("touchstart", slideReady);
        window.addEventListener("touchend", slideFinish);

        // Function to handle slider ready state
        function slideReady(e) {
            e.preventDefault();
            clicked = 1;
            window.addEventListener("mousemove", slideMove);
            window.addEventListener("touchmove", slideMove);
        }

        // Function to handle slider finish state
        function slideFinish() {
            clicked = 0;
        }

        // Function to handle slider movement
        function slideMove(e) {
            var pos;
            if (clicked == 0) return false;
            pos = getCursorPos(e)
            if (pos < 0) pos = 0;
            if (pos > w) pos = w;
            slide(pos);
        }

        // Function to get cursor position
        function getCursorPos(e) {
            var x = 0;
            e = (e.changedTouches) ? e.changedTouches[0] : e;
            x = e.pageX - overlay.getBoundingClientRect().left;
            x = x - window.pageXOffset;
            return x;
        }

        // Function to resize image and position slider
        function slide(x) {
            overlay.style.width = x + "px";
            slider.style.left = overlay.offsetWidth - (slider.offsetWidth / 2) + "px";
        }
    }
}

// Call the function on page load
initComparisons();
